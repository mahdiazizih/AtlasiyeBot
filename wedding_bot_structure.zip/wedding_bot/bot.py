# Entry point for the bot
