# Route messages to group-specific handlers
