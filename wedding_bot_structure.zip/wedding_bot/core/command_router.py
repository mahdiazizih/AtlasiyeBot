# Route commands to appropriate handlers
