# Configuration for each group
