# Handlers for group -4818872906 (e.g., صندوق اعتباری)
